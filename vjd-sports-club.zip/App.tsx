import React, { useState, useEffect, useCallback, FC, FormEvent } from 'react';
import { View, AuthMode, ClubTab, User, Club, ClubMember, ChatMessage, MenuItem, Promotion, Post } from './types';
import { MOCK_CLUBS, MOCK_POSTS, VjdLogo, QrCodeIcon, UsersIcon, ChatIcon, MenuIcon, TagIcon, InfoIcon, LogoutIcon, LikeIcon, CommentIcon, ShareIcon } from './constants';

// Reusable UI Components
const Button: FC<{ onClick: () => void | Promise<void>; children: React.ReactNode; className?: string; variant?: 'primary' | 'secondary'; disabled?: boolean }> = ({ onClick, children, className = '', variant = 'primary', disabled = false }) => {
  const baseClasses = 'w-full text-white font-bold py-3 px-4 rounded-lg shadow-md transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2';
  const variantClasses = variant === 'primary' 
    ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500' 
    : 'bg-blue-800 hover:bg-blue-900 focus:ring-blue-700';
  const disabledClasses = disabled ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-90';
  
  return (
    <button onClick={onClick} disabled={disabled} className={`${baseClasses} ${variantClasses} ${disabledClasses} ${className}`}>
      {children}
    </button>
  );
};

const Input: FC<{ value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder: string; type?: string; required?: boolean }> = ({ value, onChange, placeholder, type = 'text', required = false }) => (
  <input
    type={type}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 transition-shadow"
  />
);

const Card: FC<{ children: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = '', onClick }) => (
    <div onClick={onClick} className={`bg-white rounded-xl shadow-md overflow-hidden ${className}`}>
        {children}
    </div>
);

// Header Component
const Header: FC<{ user: User | null; onLogout: () => void; onLoginClick: () => void }> = ({ user, onLogout, onLoginClick }) => (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-lg z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
                <VjdLogo className="h-12 w-auto" />
                {user ? (
                    <div className="flex items-center space-x-4">
                        <span className="font-semibold text-gray-700 hidden sm:block">Chào, {user.name.split(' ')[0]}!</span>
                        <button onClick={onLogout} className="text-gray-500 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-gray-100">
                            <LogoutIcon className="w-6 h-6"/>
                        </button>
                    </div>
                ) : (
                    <button onClick={onLoginClick} className="text-sm font-bold text-red-600 hover:underline">
                        Đăng ký / Đăng nhập
                    </button>
                )}
            </div>
        </div>
    </header>
);

// Feed Screen Component
const FeedScreen: FC = () => {
    const PostCard: FC<{ post: Post }> = ({ post }) => (
        <Card>
            <div className="p-4">
                <div className="flex items-center mb-4">
                    <img src={post.author.avatarUrl} alt={post.author.name} className="w-10 h-10 rounded-full mr-3"/>
                    <div>
                        <p className="font-bold text-gray-800">{post.author.name}</p>
                        <p className="text-xs text-gray-500">{post.timestamp}</p>
                    </div>
                </div>
                <p className="text-gray-700 mb-4">{post.text}</p>
            </div>
            {post.imageUrl && <img src={post.imageUrl} alt="Post content" className="w-full h-auto"/>}
            <div className="p-2">
                <div className="flex justify-between items-center text-gray-500 text-sm mb-1 px-2">
                    <span>{post.likes} lượt thích</span>
                    <span>{post.comments} bình luận</span>
                </div>
                <div className="border-t border-gray-200 my-1"></div>
                <div className="flex justify-around text-gray-600 font-semibold">
                    <button className="flex-1 flex items-center justify-center p-2 hover:bg-gray-100 rounded-lg transition-colors"><LikeIcon className="w-5 h-5 mr-2"/> Thích</button>
                    <button className="flex-1 flex items-center justify-center p-2 hover:bg-gray-100 rounded-lg transition-colors"><CommentIcon className="w-5 h-5 mr-2"/> Bình luận</button>
                    <button className="flex-1 flex items-center justify-center p-2 hover:bg-gray-100 rounded-lg transition-colors"><ShareIcon className="w-5 h-5 mr-2"/> Chia sẻ</button>
                </div>
            </div>
        </Card>
    );

    return (
        <div className="max-w-xl mx-auto p-4 space-y-6">
            <h1 className="text-2xl font-bold text-blue-900">Nhật ký hoạt động</h1>
            {MOCK_POSTS.map(post => <PostCard key={post.id} post={post} />)}
        </div>
    );
};

// Auth Screen Component
const AuthScreen: FC<{ onAuthSuccess: (user: User) => void; }> = ({ onAuthSuccess }) => {
    const [mode, setMode] = useState<AuthMode>(AuthMode.Login);
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (mode === AuthMode.Register) {
            const newUser: User = { id: Date.now(), name, phone, email, password };
            onAuthSuccess(newUser);
        } else {
            // Simulate login
            onAuthSuccess({ id: 1, name: 'Học viên Demo', phone, password });
        }
    };

    return (
        <div className="max-w-md mx-auto mt-8 p-4 sm:p-8">
            <Card>
                <div className="p-8">
                    <h2 className="text-2xl font-bold text-center text-blue-900 mb-2">
                        {mode === AuthMode.Login ? 'Chào mừng trở lại!' : 'Tạo tài khoản mới'}
                    </h2>
                    <p className="text-center text-gray-500 mb-8">
                        {mode === AuthMode.Login ? 'Đăng nhập để kết nối với CLB của bạn' : 'Tham gia cộng đồng VJD Sports ngay hôm nay'}
                    </p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        {mode === AuthMode.Register && (
                            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Họ và Tên" required />
                        )}
                        <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Số điện thoại" type="tel" required />
                        <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="Mật khẩu" type="password" required />
                        {mode === AuthMode.Register && (
                            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email (không bắt buộc)" type="email" />
                        )}
                        <Button onClick={() => {}}>{mode === AuthMode.Login ? 'Đăng nhập' : 'Đăng ký'}</Button>
                    </form>
                    <div className="mt-6 text-center">
                        <button onClick={() => setMode(mode === AuthMode.Login ? AuthMode.Register : AuthMode.Login)} className="text-sm font-medium text-red-600 hover:underline">
                            {mode === AuthMode.Login ? 'Chưa có tài khoản? Đăng ký ngay' : 'Đã có tài khoản? Đăng nhập'}
                        </button>
                    </div>
                </div>
            </Card>
        </div>
    );
};


// Dashboard Screen Component
const DashboardScreen: FC<{ onCheckIn: (clubId: string) => void; onScanQR: () => void; }> = ({ onCheckIn, onScanQR }) => {
  const totalMembers = MOCK_CLUBS.reduce((sum, club) => sum + club.activeMembers, 0);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-extrabold text-blue-900">Bảng tin CLB</h1>
        <p className="mt-2 text-lg text-gray-600">
          <span className="font-bold text-red-600">{totalMembers}</span> thành viên và <span className="font-bold text-red-600">{MOCK_CLUBS.length}</span> CLB đang hoạt động!
        </p>
      </div>
      <Button onClick={onScanQR} variant="secondary">
        <div className="flex items-center justify-center space-x-2">
            <QrCodeIcon />
            <span>Check-in bằng mã QR</span>
        </div>
      </Button>
      <div className="space-y-6">
        {MOCK_CLUBS.map(club => (
          <Card key={club.id} className="transition-transform hover:scale-105">
            <div className="p-6">
              <h3 className="text-xl font-bold text-blue-900">{club.name}</h3>
              <p className="text-gray-500 mt-1">{club.address}</p>
              <p className="text-green-600 font-semibold mt-2">{club.activeMembers} thành viên đang hoạt động</p>
              <div className="mt-4">
                <Button onClick={() => onCheckIn(club.id)}>Check-in vào CLB</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};


// QR Scanner Mock Component
const QrScannerView: FC<{ onScanComplete: (clubId: string) => void }> = ({ onScanComplete }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onScanComplete(MOCK_CLUBS[0].id); // Simulate scanning the first club's QR
        }, 2500);
        return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex flex-col items-center justify-center z-50 text-white">
            <p className="text-2xl font-bold mb-4">Đang tìm mã QR...</p>
            <div className="w-64 h-64 border-4 border-dashed border-red-600 rounded-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-red-500 animate-[scan_2s_ease-in-out_infinite]"></div>
            </div>
            <p className="mt-4 text-lg">Di chuyển camera của bạn vào mã QR của CLB</p>
            <style>{`
                @keyframes scan {
                    0% { transform: translateY(-10px); }
                    50% { transform: translateY(250px); }
                    100% { transform: translateY(-10px); }
                }
            `}</style>
        </div>
    );
};

// Private Chat View (sub-component of ClubScreen)
const PrivateChatView: FC<{ partner: ClubMember; onBack: () => void }> = ({ partner, onBack }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { id: 1, author: partner.name, avatarUrl: partner.avatarUrl, text: 'Chào bạn, mình có thể giúp gì cho bạn?', timestamp: '10:45 AM' }
    ]);
    const [newMessage, setNewMessage] = useState('');

    const handleSendMessage = () => {
        if (newMessage.trim()) {
            const msg: ChatMessage = {
                id: Date.now(),
                author: 'Bạn',
                avatarUrl: 'https://picsum.photos/seed/me/40/40',
                text: newMessage.trim(),
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setMessages([...messages, msg]);
            setNewMessage('');
        }
    };
    
    return (
        <div className="flex flex-col h-[calc(100vh-14rem)]">
            <div className="bg-white rounded-t-lg shadow-lg p-4 sticky top-20 z-10 flex items-center">
                <button onClick={onBack} className="text-gray-600 hover:text-blue-800 mr-4">&larr; Quay lại</button>
                <img src={partner.avatarUrl} alt={partner.name} className="w-10 h-10 rounded-full mr-3"/>
                <h3 className="text-xl font-bold text-blue-900">Nhắn tin với {partner.name}</h3>
            </div>
            <Card className="flex flex-col flex-1 mt-1">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map(msg => (
                        <div key={msg.id} className={`flex items-end gap-2 ${msg.author === 'Bạn' ? 'justify-end' : ''}`}>
                            {msg.author !== 'Bạn' && <img src={msg.avatarUrl} alt={msg.author} className="w-8 h-8 rounded-full" />}
                            <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.author === 'Bạn' ? 'bg-red-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
                                <p className="text-sm">{msg.text}</p>
                                <p className={`text-xs mt-1 ${msg.author === 'Bạn' ? 'text-red-200' : 'text-gray-500'}`}>{msg.author}, {msg.timestamp}</p>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t bg-white flex items-center space-x-2">
                    <Input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder={`Nhắn tin cho ${partner.name}...`} />
                    <button onClick={handleSendMessage} className="bg-red-600 text-white p-3 rounded-full hover:bg-red-700 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M3.105 2.289a.75.75 0 0 0-.826.95l1.414 4.949a.75.75 0 0 0 .95.53l4.949-1.414a.75.75 0 0 0 .53-.95L8.21 3.105a.75.75 0 0 0-.95-.826L3.105 2.289Z" /><path d="M2.934 11.132A.75.75 0 0 0 2.29 12.5l2.223 6.667a.75.75 0 0 0 1.408-.47L5.313 11.9a.75.75 0 0 0-1.04-1.04l-1.34 1.341Z" /></svg>
                    </button>
                </div>
            </Card>
        </div>
    );
};


// Club Screen Component
const ClubScreen: FC<{ club: Club; onBack: () => void; }> = ({ club, onBack }) => {
    const [activeTab, setActiveTab] = useState<ClubTab>(ClubTab.Members);
    const [messages, setMessages] = useState<ChatMessage[]>(club.chat);
    const [newMessage, setNewMessage] = useState('');
    const [chattingWith, setChattingWith] = useState<ClubMember | null>(null);

    const handleSendMessage = () => {
        if (newMessage.trim()) {
            const msg: ChatMessage = {
                id: Date.now(),
                author: 'Bạn',
                avatarUrl: 'https://picsum.photos/seed/me/40/40',
                text: newMessage.trim(),
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setMessages([...messages, msg]);
            setNewMessage('');
        }
    };

    const tabs = [
        { id: ClubTab.Members, icon: UsersIcon, label: 'Thành viên' },
        { id: ClubTab.Chat, icon: ChatIcon, label: 'Chat' },
        { id: ClubTab.Menu, icon: MenuIcon, label: 'Dịch vụ' },
        { id: ClubTab.Promotions, icon: TagIcon, label: 'Ưu đãi' },
        { id: ClubTab.Info, icon: InfoIcon, label: 'Thông tin' },
    ];

    if (chattingWith) {
        return <PrivateChatView partner={chattingWith} onBack={() => setChattingWith(null)} />
    }

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-t-lg shadow-lg p-4 sticky top-20 z-10">
                <button onClick={onBack} className="absolute top-4 left-4 text-gray-600 hover:text-blue-800">&larr; Quay lại</button>
                <h2 className="text-2xl font-bold text-center text-blue-900">{club.name}</h2>
                <p className="text-center text-gray-500">{club.address}</p>
            </div>
            
            <div className="p-4 bg-gray-50 pb-24">
                {activeTab === ClubTab.Members && (
                    <div className="space-y-3">
                        {club.members.map(m => (
                             <Card key={m.id} className="p-4 flex items-center justify-between hover:bg-gray-50 cursor-pointer" onClick={() => setChattingWith(m)}>
                                <div className="flex items-center space-x-4">
                                    <img src={m.avatarUrl} alt={m.name} className="w-12 h-12 rounded-full"/>
                                    <span className="font-semibold text-gray-800">{m.name}</span>
                                </div>
                                {m.checkedIn ? 
                                    <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded-full">ĐÃ CHECK-IN</span>
                                    :
                                    <span className="text-xs font-bold bg-gray-200 text-gray-600 px-2 py-1 rounded-full">OFFLINE</span>
                                }
                            </Card>
                        ))}
                    </div>
                )}
                 {activeTab === ClubTab.Chat && (
                    <Card className="flex flex-col h-[calc(100vh-22rem)]">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {messages.map(msg => (
                                <div key={msg.id} className={`flex items-end gap-2 ${msg.author === 'Bạn' ? 'justify-end' : ''}`}>
                                    {msg.author !== 'Bạn' && <img src={msg.avatarUrl} alt={msg.author} className="w-8 h-8 rounded-full" />}
                                    <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.author === 'Bạn' ? 'bg-red-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
                                        <p className="text-sm">{msg.text}</p>
                                        <p className={`text-xs mt-1 ${msg.author === 'Bạn' ? 'text-red-200' : 'text-gray-500'}`}>{msg.author}, {msg.timestamp}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="p-4 border-t bg-white flex items-center space-x-2">
                            <Input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Nhắn tin vào nhóm..." />
                            <button onClick={handleSendMessage} className="bg-red-600 text-white p-3 rounded-full hover:bg-red-700 transition">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M3.105 2.289a.75.75 0 0 0-.826.95l1.414 4.949a.75.75 0 0 0 .95.53l4.949-1.414a.75.75 0 0 0 .53-.95L8.21 3.105a.75.75 0 0 0-.95-.826L3.105 2.289Z" /><path d="M2.934 11.132A.75.75 0 0 0 2.29 12.5l2.223 6.667a.75.75 0 0 0 1.408-.47L5.313 11.9a.75.75 0 0 0-1.04-1.04l-1.34 1.341Z" /></svg>
                            </button>
                        </div>
                    </Card>
                )}
                {activeTab === ClubTab.Menu && (
                     <div className="space-y-3">
                        {club.menu.map(item => (
                            <Card key={item.id} className="p-4">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-bold text-lg text-blue-900">{item.name}</h4>
                                        <p className="text-gray-600 text-sm">{item.description}</p>
                                        <p className="font-bold text-red-600 mt-2">{item.price}</p>
                                    </div>
                                    <button className="bg-green-500 text-white font-bold text-sm px-4 py-2 rounded-lg hover:bg-green-600">Đặt hàng</button>
                                </div>
                            </Card>
                        ))}
                    </div>
                )}
                 {activeTab === ClubTab.Promotions && (
                    <div className="space-y-4">
                        {club.promotions.length > 0 ? club.promotions.map(p => (
                           <Card key={p.id} className="p-6 bg-gradient-to-br from-red-50 to-blue-50">
                                <h4 className="font-bold text-lg text-red-600">{p.title}</h4>
                                <p className="text-gray-700 mt-2">{p.description}</p>
                           </Card>
                        )) : (
                            <Card className="p-6 text-center text-gray-500">
                                <p>Hiện chưa có chương trình ưu đãi nào.</p>
                            </Card>
                        )}
                    </div>
                )}
                {activeTab === ClubTab.Info && (
                    <Card className="p-6">
                        <h3 className="font-bold text-xl text-blue-900 mb-4">Thông tin CLB</h3>
                        <div className="space-y-3 text-gray-700">
                            <p><strong className="w-32 inline-block">Địa chỉ:</strong> {club.address}</p>
                            <p><strong className="w-32 inline-block">Giờ hoạt động:</strong> {club.operatingHours}</p>
                        </div>
                    </Card>
                )}
            </div>

            {/* Bottom Nav */}
            <div className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
                <div className="max-w-4xl mx-auto flex justify-around">
                    {tabs.map(tab => (
                        <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 flex flex-col items-center justify-center py-2 text-xs font-medium transition-colors ${activeTab === tab.id ? 'text-red-600' : 'text-gray-500 hover:bg-gray-100'}`}>
                            <tab.icon className={`w-6 h-6 mb-1 ${activeTab === tab.id ? 'text-red-600' : 'text-gray-500'}`} />
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};


// Main App Component
export default function App() {
  const [view, setView] = useState<View>(View.Feed);
  const [user, setUser] = useState<User | null>(null);
  const [checkedInClub, setCheckedInClub] = useState<Club | null>(null);

  useEffect(() => {
    // If a user logs in, show the dashboard. On logout, show the feed.
    if (user) {
        setView(View.Dashboard);
    } else {
        setView(View.Feed);
        setCheckedInClub(null);
    }
  }, [user]);
  
  const handleAuthSuccess = (authedUser: User) => {
    // In a real app, this would save to a DB and return a user object.
    setUser(authedUser);
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleCheckIn = (clubId: string) => {
    const club = MOCK_CLUBS.find(c => c.id === clubId);
    if (club) {
      setCheckedInClub(club);
      setView(View.Club);
    }
  };
  
  const handleBackToDashboard = () => {
      setCheckedInClub(null);
      setView(View.Dashboard);
  };
  
  const renderView = () => {
    switch(view) {
      case View.Feed:
        return <FeedScreen />;
      case View.Auth:
        return <AuthScreen onAuthSuccess={handleAuthSuccess} />;
      case View.Dashboard:
        return <DashboardScreen onCheckIn={handleCheckIn} onScanQR={() => setView(View.QrScanner)} />;
      case View.Club:
        return checkedInClub ? <ClubScreen club={checkedInClub} onBack={handleBackToDashboard}/> : <DashboardScreen onCheckIn={handleCheckIn} onScanQR={() => setView(View.QrScanner)} />;
      case View.QrScanner:
        return <QrScannerView onScanComplete={handleCheckIn} />;
      default:
        return <FeedScreen />;
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header user={user} onLogout={handleLogout} onLoginClick={() => setView(View.Auth)}/>
      <main className="pt-20">
        {renderView()}
      </main>
    </div>
  );
}
