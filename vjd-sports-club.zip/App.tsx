import React, { useState, useEffect, useCallback, FC, FormEvent, useMemo } from 'react';
import { View, AuthMode, ClubTab, User, Club, ClubMember, ChatMessage, MenuItem, Promotion, Booking } from './types';
import { MOCK_CLUBS, MOCK_USERS, VjdLogo, QrCodeIcon, UsersIcon, ChatIcon, MenuIcon, TagIcon, ClockIcon, HomeIcon, CalendarDaysIcon, SparklesIcon, MegaphoneIcon, LogoutIcon, HandshakeIcon } from './constants';
import { generateClubPromotion } from './services/geminiService';

// Reusable UI Components
const Button: FC<{ onClick: () => void | Promise<void>; children: React.ReactNode; className?: string; variant?: 'primary' | 'secondary'; disabled?: boolean }> = ({ onClick, children, className = '', variant = 'primary', disabled = false }) => {
  const baseClasses = 'w-full text-white font-bold py-3 px-4 rounded-lg shadow-md transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2';
  const variantClasses = variant === 'primary' 
    ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500' 
    : 'bg-blue-800 hover:bg-blue-900 focus:ring-blue-700';
  const disabledClasses = disabled ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-90';
  
  return (
    <button onClick={onClick} disabled={disabled} className={`${baseClasses} ${variantClasses} ${disabledClasses} ${className}`}>
      {children}
    </button>
  );
};

const Input: FC<{ value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder: string; type?: string; required?: boolean }> = ({ value, onChange, placeholder, type = 'text', required = false }) => (
  <input
    type={type}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800 transition-shadow"
  />
);

const Card: FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
    <div className={`bg-white rounded-xl shadow-md overflow-hidden ${className}`}>
        {children}
    </div>
);

const LoadingSpinner: FC = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-red-600"></div>
    </div>
);

// Header Component
const Header: FC<{ user: User | null; onLogout: () => void; onLoginClick: () => void }> = ({ user, onLogout, onLoginClick }) => (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-lg z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
                <VjdLogo className="h-12 w-auto" />
                {user ? (
                    <div className="flex items-center space-x-4">
                        <span className="font-semibold text-gray-700 hidden sm:block">Chào, {user.name.split(' ')[0]}!</span>
                        <button onClick={onLogout} className="text-gray-500 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-gray-100">
                            <LogoutIcon className="w-6 h-6"/>
                        </button>
                    </div>
                ) : (
                    <button onClick={onLoginClick} className="text-sm font-bold text-red-600 hover:underline">
                        Đăng ký / Đăng nhập
                    </button>
                )}
            </div>
        </div>
    </header>
);

// Auth Screen Component
const AuthScreen: FC<{ onLogin: (credentials: { phone: string, password: string }) => void; onRegister: (user: User) => void; users: User[] }> = ({ onLogin, onRegister, users }) => {
    const [mode, setMode] = useState<AuthMode>(AuthMode.Login);
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (mode === AuthMode.Register) {
            if (users.some(u => u.phone === phone)) {
                alert('Số điện thoại đã được đăng ký. Vui lòng sử dụng số khác.');
                return;
            }
            const newUser: User = { id: Date.now(), name, phone, email, password };
            onRegister(newUser);
        } else {
            onLogin({ phone, password });
        }
    };

    return (
        <div className="max-w-md mx-auto mt-8 p-4 sm:p-8">
            <Card>
                <div className="p-8">
                    <h2 className="text-2xl font-bold text-center text-blue-900 mb-2">
                        {mode === AuthMode.Login ? 'Chào mừng trở lại!' : 'Tạo tài khoản mới'}
                    </h2>
                    <p className="text-center text-gray-500 mb-8">
                        {mode === AuthMode.Login ? 'Đăng nhập để kết nối với CLB của bạn' : 'Tham gia cộng đồng VJD Sports ngay hôm nay'}
                    </p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        {mode === AuthMode.Register && (
                            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Họ và Tên" required />
                        )}
                        <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Số điện thoại" type="tel" required />
                        <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="Mật khẩu" type="password" required />

                        {mode === AuthMode.Register && (
                            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email (không bắt buộc)" type="email" />
                        )}
                        <Button onClick={() => {}}>{mode === AuthMode.Login ? 'Đăng nhập' : 'Đăng ký'}</Button>
                    </form>
                    <div className="mt-6 text-center">
                        <button onClick={() => setMode(mode === AuthMode.Login ? AuthMode.Register : AuthMode.Login)} className="text-sm font-medium text-red-600 hover:underline">
                            {mode === AuthMode.Login ? 'Chưa có tài khoản? Đăng ký ngay' : 'Đã có tài khoản? Đăng nhập'}
                        </button>
                    </div>
                </div>
            </Card>
        </div>
    );
};


// Dashboard Screen Component
const DashboardScreen: FC<{ onCheckIn: (clubId: string) => void; onScanQR: () => void; }> = ({ onCheckIn, onScanQR }) => {
  const totalMembers = MOCK_CLUBS.reduce((sum, club) => sum + club.activeMembers, 0);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-extrabold text-blue-900">Bảng tin CLB</h1>
        <p className="mt-2 text-lg text-gray-600">
          <span className="font-bold text-red-600">{totalMembers}</span> thành viên và <span className="font-bold text-red-600">{MOCK_CLUBS.length}</span> CLB đang hoạt động!
        </p>
      </div>
      <Button onClick={onScanQR} variant="secondary">
        <div className="flex items-center justify-center space-x-2">
            <QrCodeIcon />
            <span>Check-in bằng mã QR</span>
        </div>
      </Button>
      <div className="space-y-6">
        {MOCK_CLUBS.map(club => (
          <Card key={club.id} className="transition-transform hover:scale-105">
            <div className="p-6">
              <h3 className="text-xl font-bold text-blue-900">{club.name}</h3>
              <p className="text-gray-500 mt-1">{club.address}</p>
              <p className="text-green-600 font-semibold mt-2">{club.activeMembers} thành viên đang hoạt động</p>
              <div className="mt-4">
                <Button onClick={() => onCheckIn(club.id)}>Check-in vào CLB</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};


// QR Scanner Mock Component
const QrScannerView: FC<{ onScanComplete: (clubId: string) => void }> = ({ onScanComplete }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onScanComplete(MOCK_CLUBS[0].id); // Simulate scanning the first club's QR
        }, 2500);
        return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex flex-col items-center justify-center z-50 text-white">
            <p className="text-2xl font-bold mb-4">Đang tìm mã QR...</p>
            <div className="w-64 h-64 border-4 border-dashed border-red-600 rounded-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-red-500 animate-[scan_2s_ease-in-out_infinite]"></div>
            </div>
            <p className="mt-4 text-lg">Di chuyển camera của bạn vào mã QR của CLB</p>
            <style>{`
                @keyframes scan {
                    0% { transform: translateY(-10px); }
                    50% { transform: translateY(250px); }
                    100% { transform: translateY(-10px); }
                }
            `}</style>
        </div>
    );
};


// Club Screen Sub-Components

const HomeView: FC<{ club: Club }> = ({ club }) => (
    <div className="p-4 space-y-4">
        <Card className="p-6 text-center">
            <h3 className="text-2xl font-bold text-blue-900">Chào mừng đến với {club.name}</h3>
            <p className="text-gray-600 mt-2">Nơi đam mê cầu lông không bao giờ tắt!</p>
        </Card>
        <Card className="p-6">
            <h4 className="font-bold text-lg text-blue-900 mb-3">Thông tin CLB</h4>
            <div className="space-y-2 text-gray-700">
                <p><strong className="w-32 inline-block">Địa chỉ:</strong> {club.address}</p>
                <p><strong className="w-32 inline-block">Giờ hoạt động:</strong> {club.operatingHours}</p>
                <p><strong className="w-32 inline-block">Đang hoạt động:</strong> {club.members.filter(m => m.checkedIn).length} / {club.members.length} thành viên</p>
            </div>
        </Card>
    </div>
);

const BookingView: FC<{ club: Club }> = ({ club }) => {
    const [bookings, setBookings] = useState<Booking[]>(club.bookings);

    const handleBookSlot = (courtId: number, timeSlot: string) => {
        if (bookings.some(b => b.courtId === courtId && b.timeSlot === timeSlot)) {
            alert('Khung giờ này đã được đặt. Vui lòng chọn giờ khác.');
            return;
        }
        if(confirm(`Bạn có chắc muốn đặt ${club.courts.find(c=>c.id === courtId)?.name} vào lúc ${timeSlot} không?`)) {
            setBookings(prev => [...prev, { courtId, timeSlot }]);
            alert('Đặt sân thành công!');
        }
    };

    const timeSlots = useMemo(() => {
        const [start, end] = club.operatingHours.split(' - ').map(t => parseInt(t.split(':')[0]));
        return Array.from({ length: end - start }, (_, i) => `${(start + i).toString().padStart(2, '0')}:00`);
    }, [club.operatingHours]);

    return (
        <div className="p-4 space-y-4">
            <Card>
                <h3 className="text-xl font-bold text-blue-900 p-4 border-b">Lịch đặt sân hôm nay</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="p-3 font-semibold">Sân</th>
                                {timeSlots.map(slot => <th key={slot} className="p-2 w-20 text-center font-semibold">{slot}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {club.courts.map(court => (
                                <tr key={court.id} className="border-b last:border-none">
                                    <td className="p-3 font-bold">{court.name}</td>
                                    {timeSlots.map(slot => {
                                        const isBooked = bookings.some(b => b.courtId === court.id && b.timeSlot === slot);
                                        return (
                                            <td key={slot} className="p-1 text-center">
                                                <button 
                                                    onClick={() => handleBookSlot(court.id, slot)}
                                                    disabled={isBooked}
                                                    className={`w-full h-10 rounded-md text-xs font-bold transition ${isBooked ? 'bg-red-200 text-red-800 cursor-not-allowed' : 'bg-green-100 text-green-800 hover:bg-green-200'}`}
                                                >
                                                    {isBooked ? 'Đã đặt' : 'Đặt'}
                                                </button>
                                            </td>
                                        )
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

// Club Screen Component
const ClubScreen: FC<{ club: Club; onBack: () => void; user: User | null }> = ({ club, onBack, user }) => {
    const [activeTab, setActiveTab] = useState<ClubTab>(ClubTab.Home);
    const [activeSubTab, setActiveSubTab] = useState('default');
    
    // State for chat
    const [messages, setMessages] = useState<ChatMessage[]>(club.chat);
    const [newMessage, setNewMessage] = useState('');

    // State for promotions
    const [promotions, setPromotions] = useState<Promotion[]>(club.promotions);
    const [isGeneratingPromo, setIsGeneratingPromo] = useState(false);

    const handleSendMessage = () => {
        if (newMessage.trim() && user) {
            const msg: ChatMessage = {
                id: Date.now(),
                author: user.name,
                avatarUrl: `https://i.pravatar.cc/40?u=${user.id}`,
                text: newMessage.trim(),
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setMessages([...messages, msg]);
            setNewMessage('');
        }
    };
    
    const handleSendPairingRequest = () => {
        if (user) {
            const msg: ChatMessage = {
                id: Date.now(),
                author: user.name,
                avatarUrl: `https://i.pravatar.cc/40?u=${user.id}`,
                text: '👋 Xin chào, mình muốn tìm người ghép cặp đánh giao hữu. Có ai tham gia không?',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setMessages(prev => [...prev, msg]);
            setActiveTab(ClubTab.Community);
            setActiveSubTab('chat');
        }
    };

    const handleGeneratePromotion = useCallback(async () => {
        setIsGeneratingPromo(true);
        const generatedText = await generateClubPromotion(club.name);
        const newPromo: Promotion = {
            id: Date.now(),
            title: "✨ Khuyến mãi đặc biệt từ AI ✨",
            description: generatedText
        };
        setPromotions(prev => [newPromo, ...prev]);
        setIsGeneratingPromo(false);
    }, [club.name]);


    const TabButton: FC<{ current: string, target: string, set: (s:string) => void, children: React.ReactNode }> = ({current, target, set, children}) => (
        <button
            onClick={() => set(target)}
            className={`px-4 py-2 text-sm font-bold rounded-full transition ${current === target ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
        >
            {children}
        </button>
    );

    const renderContent = () => {
        switch(activeTab) {
            case ClubTab.Home:
                return <HomeView club={club} />;
            case ClubTab.Booking:
                return <BookingView club={club} />;
            case ClubTab.Services:
                return <div className="p-4 space-y-4">
                    <div className="flex space-x-2"><TabButton current={activeSubTab} target='menu' set={setActiveSubTab}>Dịch vụ & Sản phẩm</TabButton><TabButton current={activeSubTab} target='coaches' set={setActiveSubTab}>Thuê HLV</TabButton></div>
                    {activeSubTab === 'menu' && <div className="space-y-3">
                        {club.menu.map(item => (
                            <Card key={item.id} className="p-4">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-bold text-lg text-blue-900">{item.name}</h4>
                                        <p className="text-gray-600 text-sm">{item.description}</p>
                                        <p className="font-bold text-red-600 mt-2">{item.price}</p>
                                    </div>
                                    <button className="bg-green-500 text-white font-bold text-sm px-4 py-2 rounded-lg hover:bg-green-600">Đặt hàng</button>
                                </div>
                            </Card>
                        ))}
                    </div>}
                    {activeSubTab === 'coaches' && <div className="space-y-3">
                        {club.coaches.length > 0 ? club.coaches.map(c => (
                            <Card key={c.id} className="p-4 flex items-center space-x-4">
                                <img src={c.avatarUrl} alt={c.name} className="w-20 h-20 rounded-full"/>
                                <div>
                                    <h4 className="font-bold text-lg text-blue-900">{c.name}</h4>
                                    <p className="text-gray-600">{c.specialty}</p>
                                    <p className="font-bold text-red-600 mt-1">{c.rate}</p>
                                    <button className="mt-2 bg-blue-800 text-white font-bold text-sm px-4 py-2 rounded-lg hover:bg-blue-900">Liên hệ</button>
                                </div>
                            </Card>
                        )) : <p className="text-center text-gray-500 p-8">CLB hiện chưa có HLV để đặt.</p>}
                    </div>}
                </div>;
            case ClubTab.Community:
                 return <div className="p-4 space-y-4">
                    <div className="flex space-x-2"><TabButton current={activeSubTab} target='members' set={setActiveSubTab}>Thành viên</TabButton><TabButton current={activeSubTab} target='chat' set={setActiveSubTab}>Chat chung</TabButton></div>
                    {activeSubTab === 'members' && <div className="space-y-3">
                        {club.members.map(m => (
                            <Card key={m.id} className="p-4 flex items-center justify-between">
                                <div className="flex items-center space-x-4">
                                    <img src={m.avatarUrl} alt={m.name} className="w-12 h-12 rounded-full"/>
                                    <span className="font-semibold text-gray-800">{m.name}</span>
                                </div>
                                {m.checkedIn && <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded-full">ĐÃ CHECK-IN</span>}
                            </Card>
                        ))}
                    </div>}
                    {activeSubTab === 'chat' && <Card className="flex flex-col h-[calc(100vh-25rem)]">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {messages.map(msg => {
                                const isMyMessage = user && msg.author === user.name;
                                return (
                                <div key={msg.id} className={`flex items-end gap-2 ${isMyMessage ? 'justify-end' : ''}`}>
                                    {!isMyMessage && <img src={msg.avatarUrl} alt={msg.author} className="w-8 h-8 rounded-full" />}
                                    <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${isMyMessage ? 'bg-red-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
                                        <p className="text-sm">{msg.text}</p>
                                        <p className={`text-xs mt-1 ${isMyMessage ? 'text-red-200' : 'text-gray-500'}`}>{msg.author}, {msg.timestamp}</p>
                                    </div>
                                </div>
                            )})}
                        </div>
                        <div className="p-4 border-t bg-white flex items-center space-x-2">
                            <Input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Nhắn tin vào nhóm..." />
                            <button onClick={handleSendPairingRequest} title="Gửi yêu cầu ghép cặp" className="text-blue-600 p-3 rounded-full hover:bg-blue-100 transition">
                                <HandshakeIcon className="w-5 h-5"/>
                            </button>
                            <button onClick={handleSendMessage} className="bg-red-600 text-white p-3 rounded-full hover:bg-red-700 transition">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M3.105 2.289a.75.75 0 0 0-.826.95l1.414 4.949a.75.75 0 0 0 .95.53l4.949-1.414a.75.75 0 0 0 .53-.95L8.21 3.105a.75.75 0 0 0-.95-.826L3.105 2.289Z" /><path d="M2.934 11.132A.75.75 0 0 0 2.29 12.5l2.223 6.667a.75.75 0 0 0 1.408-.47L5.313 11.9a.75.75 0 0 0-1.04-1.04l-1.34 1.341Z" /></svg>
                            </button>
                        </div>
                    </Card>}
                </div>;
            case ClubTab.Events:
                return <div className="p-4 space-y-4">
                    <div className="flex space-x-2"><TabButton current={activeSubTab} target='activities' set={setActiveSubTab}>Lịch hoạt động</TabButton><TabButton current={activeSubTab} target='promotions' set={setActiveSubTab}>Khuyến mãi</TabButton></div>
                    {activeSubTab === 'activities' && <div className="space-y-3">
                        {club.activities.length > 0 ? club.activities.map(a => (
                            <Card key={a.id} className="p-4">
                                <p className="font-semibold text-red-600">{a.time}</p>
                                <h4 className="font-bold text-lg text-blue-900 mt-1">{a.title}</h4>
                                <p className="text-gray-600 text-sm">{a.description}</p>
                            </Card>
                        )) : <p className="text-center text-gray-500 p-8">Chưa có hoạt động nào được lên lịch.</p>}
                    </div>}
                    {activeSubTab === 'promotions' && <div className="space-y-4">
                        <Button onClick={handleGeneratePromotion} disabled={isGeneratingPromo} variant="secondary">
                            {isGeneratingPromo ? 'Đang tạo ý tưởng...' : '✨ Tạo ý tưởng khuyến mãi với AI'}
                        </Button>
                         {isGeneratingPromo && <LoadingSpinner />}
                        {promotions.map(p => (
                           <Card key={p.id} className="p-6 bg-gradient-to-br from-red-50 to-blue-50">
                                <h4 className="font-bold text-lg text-red-600">{p.title}</h4>
                                <p className="text-gray-700 mt-2">{p.description}</p>
                           </Card>
                        ))}
                    </div>}
                </div>;
            default:
              return null;
        }
    }
    
    const tabs = [
        { id: ClubTab.Home, icon: HomeIcon, label: 'Trang chủ' },
        { id: ClubTab.Booking, icon: CalendarDaysIcon, label: 'Đặt sân' },
        { id: ClubTab.Services, icon: SparklesIcon, label: 'Dịch vụ' },
        { id: ClubTab.Community, icon: UsersIcon, label: 'Cộng đồng' },
        { id: ClubTab.Events, icon: MegaphoneIcon, label: 'Sự kiện' },
    ];

    const handleTabClick = (tabId: ClubTab) => {
        setActiveTab(tabId);
        // Reset sub-tabs to default when switching main tabs
        if(tabId === ClubTab.Services) setActiveSubTab('menu');
        else if(tabId === ClubTab.Community) setActiveSubTab('members');
        else if(tabId === ClubTab.Events) setActiveSubTab('activities');
        else setActiveSubTab('default');
    }

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-t-lg shadow-lg p-4 sticky top-20 z-10">
                <button onClick={onBack} className="absolute top-4 left-4 text-gray-600 hover:text-blue-800">&larr; Quay lại</button>
                <h2 className="text-2xl font-bold text-center text-blue-900">{club.name}</h2>
                <p className="text-center text-gray-500 text-sm">{club.address}</p>
            </div>
            
            <div className="bg-gray-50 pb-24 min-h-[calc(100vh-14rem)]">
                {renderContent()}
            </div>

            {/* Bottom Nav */}
            <div className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
                <div className="max-w-4xl mx-auto flex justify-around">
                    {tabs.map(tab => (
                        <button key={tab.id} onClick={() => handleTabClick(tab.id)} className={`flex-1 flex flex-col items-center justify-center py-2 text-xs font-medium transition-colors ${activeTab === tab.id ? 'text-red-600' : 'text-gray-500 hover:bg-gray-100'}`}>
                            <tab.icon className={`w-6 h-6 mb-1`} />
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};


// Main App Component
export default function App() {
  const [view, setView] = useState<View>(View.Auth);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [user, setUser] = useState<User | null>(null);
  const [checkedInClub, setCheckedInClub] = useState<Club | null>(null);

  useEffect(() => {
    setView(user ? View.Dashboard : View.Auth);
  }, [user]);

  const handleLogin = (credentials: { phone: string, password: string }) => {
    const foundUser = users.find(u => u.phone === credentials.phone && u.password === credentials.password);
    if (foundUser) {
        setUser(foundUser);
    } else {
        alert('Số điện thoại hoặc mật khẩu không chính xác.');
    }
  };
  
  const handleRegister = (newUser: User) => {
    setUsers(prev => [...prev, newUser]);
    setUser(newUser); // Automatically log in after registration
  };

  const handleLogout = () => {
    setUser(null);
    setCheckedInClub(null);
    setView(View.Auth);
  };

  const handleCheckIn = (clubId: string) => {
    const club = MOCK_CLUBS.find(c => c.id === clubId);
    if (club) {
      setCheckedInClub(club);
      setView(View.Club);
    }
  };
  
  const handleBackToDashboard = () => {
      setCheckedInClub(null);
      setView(View.Dashboard);
  };
  
  const renderView = () => {
    switch(view) {
      case View.Auth:
        return <AuthScreen onLogin={handleLogin} onRegister={handleRegister} users={users} />;
      case View.Dashboard:
        return <DashboardScreen onCheckIn={handleCheckIn} onScanQR={() => setView(View.QrScanner)} />;
      case View.Club:
        return checkedInClub ? <ClubScreen club={checkedInClub} onBack={handleBackToDashboard} user={user} /> : <DashboardScreen onCheckIn={handleCheckIn} onScanQR={() => setView(View.QrScanner)} />;
      case View.QrScanner:
        return <QrScannerView onScanComplete={handleCheckIn} />;
      default:
        return <AuthScreen onLogin={handleLogin} onRegister={handleRegister} users={users} />;
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header user={user} onLogout={handleLogout} onLoginClick={() => setView(View.Auth)}/>
      <main className="pt-20">
        {renderView()}
      </main>
    </div>
  );
}
