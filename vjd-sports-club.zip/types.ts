export enum View {
  Auth,
  Dashboard,
  Club,
  QrScanner,
}

export enum AuthMode {
  Login,
  Register,
}

export enum ClubTab {
  Home,
  Booking,
  Services,
  Community,
  Events,
}

export interface User {
  id: number;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  club?: string;
  password?: string;
}

export interface ClubMember {
  id: number;
  name: string;
  avatarUrl: string;
  checkedIn: boolean;
}

export interface ChatMessage {
  id: number;
  author: string;
  avatarUrl: string;
  text: string;
  timestamp: string;
}

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: string;
}

export interface Promotion {
  id: number;
  title: string;
  description: string;
}

export interface Court {
  id: number;
  name: string;
}

export interface Booking {
  courtId: number;
  timeSlot: string; // "HH:mm"
}

export interface Coach {
  id: number;
  name: string;
  avatarUrl: string;
  specialty: string;
  rate: string;
}

export interface ClubActivity {
  id: number;
  title: string;
  time: string;
  description: string;
}

export interface Club {
  id: string;
  name: string;
  address: string;
  activeMembers: number;
  operatingHours: string;
  members: ClubMember[];
  chat: ChatMessage[];
  menu: MenuItem[];
  promotions: Promotion[];
  courts: Court[];
  bookings: Booking[];
  coaches: Coach[];
  activities: ClubActivity[];
}
