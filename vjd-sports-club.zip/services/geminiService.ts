import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

if (!process.env.API_KEY) {
  // This is a fallback for development environments where the key might not be set.
  // In a production environment, the key is expected to be present.
  console.warn(
    "API_KEY environment variable not set. Gemini API calls will fail."
  );
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateClubPromotion = async (clubName: string): Promise<string> => {
  try {
    const prompt = `Generate a short, exciting promotional message for a sports club named '${clubName}'. The promotion should be about a new special offer. Keep it under 40 words, friendly and engaging.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.8,
        topP: 0.9,
        thinkingConfig: { thinkingBudget: 0 } // Low latency for UI interaction
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No content generated.");
    }
    return text;
  } catch (error) {
    console.error("Error generating promotion with Gemini:", error);
    return "Không thể tạo khuyến mãi lúc này. Vui lòng thử lại sau.";
  }
};
