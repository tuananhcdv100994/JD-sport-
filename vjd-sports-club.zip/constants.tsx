import React from 'react';
import { Club, User } from './types';

export const VjdLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 400 80" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g>
      <path d="M25.79,60.5l-6.42-12.12a2.2,2.2,0,0,1,0-2.16L25.79,34.1a2.42,2.42,0,0,1,2.16,0l6.42,12.12a2.2,2.2,0,0,1,0,2.16l-6.42,12.12A2.42,2.42,0,0,1,25.79,60.5Z" fill="#1E3A8A"/>
      <path d="M47.21,60.5a2.42,2.42,0,0,1-2.16,0l-6.42-12.12a2.2,2.2,0,0,1,0-2.16L45.05,34.1a2.2,2.2,0,0,1,2.16,0l6.42,12.12a2.2,2.2,0,0,1,0,2.16Z" fill="#1E3A8A"/>
      <path d="M36.5,29.37l-12.12-6.42a2.2,2.2,0,0,1-1.08-1.08L21.14,9.75a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42a2.42,2.42,0,0,1,0,4.32l-12.12,6.42a2.2,2.2,0,0,1-1.08,1.08L21.14,53.25a2.42,2.42,0,0,1-4.32,0l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L1.46,33.69a2.42,2.42,0,0,1,0-4.32l12.12-6.42a2.2,2.2,0,0,1,1.08-1.08L26.82,9.75a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42A2.42,2.42,0,0,1,47.6,33.69l-1.08,1.08Z" fill="#1E3A8A"/>
      <path d="M36.5,47.25a2.42,2.42,0,0,1-4.32,0l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L16.82,27.63a2.42,2.42,0,0,1,0-4.32l12.12-6.42a2.2,2.2,0,0,1,1.08-1.08L42.14,3.69a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42a2.42,2.42,0,0,1,0,4.32l-12.12,6.42a2.2,2.2,0,0,1-1.08,1.08L36.5,47.25Z" fill="#1E3A8A"/>
      <path d="M34.34,36.5,22.22,34.34a2.2,2.2,0,0,1-1.08-1.08L18.9,21.14a2.42,2.42,0,0,1,4.32-2.16l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,2.16a2.42,2.42,0,0,1,2.16,4.32l-12.12,2.16a2.2,2.2,0,0,1-1.08,1.08L34.34,53.25a2.42,2.42,0,0,1-4.32-2.16l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L14.66,34.34a2.42,2.42,0,0,1-2.16-4.32l12.12-2.16a2.2,2.2,0,0,1,1.08-1.08l12.12-2.16a2.42,2.42,0,0,1,2.16,4.32L27.9,34.34a2.2,2.2,0,0,1-1.08,1.08L14.66,37.58" fill="#1E3A8A"/>
      <path d="M30,42.5a5,5,0,0,1-5-5,1.25,1.25,0,0,1,2.5,0,2.5,2.5,0,0,0,5,0,1.25,1.25,0,0,1,2.5,0,5,5,0,0,1-5,5Z" fill="#DC2626"/>
      <path d="M36.5,43.79,29.3,40.21a2.21,2.21,0,0,1-1.08-1.08l-3.58-7.21a2.42,2.42,0,0,1,4.32-2.16l3.58,7.21a2.21,2.21,0,0,1,1.08,1.08l7.21,3.58a2.42,2.42,0,0,1,2.16,4.32l-7.21,3.58a2.21,2.21,0,0,1-1.08,1.08l-3.58,7.21a2.42,2.42,0,0,1-4.32-2.16l-3.58-7.21a2.21,2.21,0,0,1-1.08-1.08l-7.21-3.58a2.42,2.42,0,0,1-2.16-4.32l7.21-3.58a2.21,2.21,0,0,1,1.08-1.08l7.21-3.58a2.42,2.42,0,0,1,2.16,4.32L36.5,34.92a2.21,2.21,0,0,1-1.08,1.08L28.21,39.58" fill="#DC2626"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(15, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(87, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(159, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(231, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(303, 36.5, 36.5)"/>
       <path d="M36.5,41.5a5,5,0,1,1,5-5,5,5,0,0,1-5,5Zm0-8.5a3.5,3.5,0,1,0,3.5,3.5A3.5,3.5,0,0,0,36.5,33Z" fill="#FBBF24"/>
    </g>
    <text x="75" y="48" font-family="Arial, sans-serif" font-size="30" font-weight="bold" fill="#1E3A8A">VJD</text>
    <text x="155" y="48" font-family="Arial, sans-serif" font-size="30" font-weight="bold" fill="#DC2626" style={{ fontStyle: 'italic' }}>sports</text>
    <text x="195" y="65" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#DC2626" style={{ fontStyle: 'italic' }}>GIVE IT YOUR ALL</text>
  </svg>
);

export const MOCK_USERS: User[] = [
  { id: 101, name: 'Trần Văn An', phone: '0912345678', password: 'password123', email: 'an.tran@email.com' },
  { id: 102, name: 'Nguyễn Thị Bình', phone: '0987654321', password: 'password123', email: 'binh.nguyen@email.com' },
];


export const MOCK_CLUBS: Club[] = [
  {
    id: 'clb-tan-binh',
    name: 'CLB Cầu Lông Tân Bình',
    address: '123 Hoàng Văn Thụ, P.2, Q.Tân Bình, TP.HCM',
    activeMembers: 42,
    operatingHours: '6:00 - 22:00',
    members: Array.from({ length: 12 }, (_, i) => ({
      id: i,
      name: `Thành viên ${i + 1}`,
      avatarUrl: `https://picsum.photos/seed/${i+1}/40/40`,
      checkedIn: i % 2 === 0,
    })),
    chat: [
      { id: 1, author: 'Sơn Tùng', avatarUrl: 'https://picsum.photos/seed/a/40/40', text: 'Tối nay có ai đặt sân không?', timestamp: '10:30 AM' },
      { id: 2, author: 'Hải Tú', avatarUrl: 'https://picsum.photos/seed/b/40/40', text: 'Mình đặt 1 sân 7-9h nhé!', timestamp: '10:32 AM' },
    ],
    menu: [
      { id: 1, name: 'Nước lọc Lavie', description: 'Chai 500ml', price: '10.000đ' },
      { id: 2, name: 'Revive Chanh Muối', description: 'Bù nước, bù khoáng', price: '15.000đ' },
      { id: 3, name: 'Cầu Super-S', description: 'Ống 12 quả', price: '180.000đ' },
    ],
    promotions: [
      { id: 1, title: 'Giảm 20% giờ chơi cuối tuần', description: 'Áp dụng cho khách hàng check-in qua app VJD Sports vào thứ 7, Chủ nhật.' },
    ],
    courts: [
        { id: 1, name: 'Sân 1' },
        { id: 2, name: 'Sân 2' },
        { id: 3, name: 'Sân 3' },
        { id: 4, name: 'Sân 4' },
    ],
    bookings: [
        { courtId: 1, timeSlot: '08:00' },
        { courtId: 2, timeSlot: '09:00' },
        { courtId: 1, timeSlot: '10:00' },
        { courtId: 3, timeSlot: '17:00' },
        { courtId: 4, timeSlot: '18:00' },
        { courtId: 2, timeSlot: '19:00' },
        { courtId: 3, timeSlot: '19:00' },
    ],
    coaches: [
        { id: 1, name: 'HLV Minh Anh', avatarUrl: 'https://picsum.photos/seed/c/80/80', specialty: 'Nâng cao kỹ thuật cơ bản', rate: '300.000đ/giờ' },
        { id: 2, name: 'HLV Tuấn Kiệt', avatarUrl: 'https://picsum.photos/seed/d/80/80', specialty: 'Chiến thuật thi đấu đôi', rate: '400.000đ/giờ' },
    ],
    activities: [
        { id: 1, title: 'Giao hữu cuối tháng', time: '18:00 - 21:00, 30/07', description: 'Giải đấu giao hữu cho tất cả thành viên, đăng ký tại quầy.' },
        { id: 2, title: 'Lớp học cầu lông trẻ em', time: '08:00 - 10:00, Thứ 7 & CN', description: 'Khai giảng lớp học cho các bé từ 6-12 tuổi.' },
    ]
  },
  {
    id: 'clb-quan-7',
    name: 'CLB Thể Thao Quận 7',
    address: '456 Nguyễn Thị Thập, P.Tân Phong, Q.7, TP.HCM',
    activeMembers: 78,
    operatingHours: '7:00 - 23:00',
     members: Array.from({ length: 25 }, (_, i) => ({
      id: i,
      name: `Vận động viên ${i + 1}`,
      avatarUrl: `https://picsum.photos/seed/${i+30}/40/40`,
      checkedIn: i % 3 === 0,
    })),
     chat: [],
     menu: [
       { id: 1, name: 'Nước Tăng Lực Redbull', description: 'Thêm năng lượng cho trận đấu', price: '20.000đ' },
     ],
     promotions: [],
     courts: [
        { id: 1, name: 'Sân A' },
        { id: 2, name: 'Sân B' },
     ],
     bookings: [],
     coaches: [],
     activities: [],
  },
];

export const QrCodeIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75C2.25 5.25 2.25 4.5 3 4.5h.75ZM9 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75H8.25a.75.75 0 0 1-.75-.75v-.75a.75.75 0 0 1 .75-.75h.75Zm.75 6a.75.75 0 0 0-1.5 0v.75h.75a.75.75 0 0 0 .75-.75v-.75Zm-3 2.25a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75v-.75ZM15 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75C12.75 5.25 12.75 4.5 13.5 4.5h.75Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.75v-.75a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75Zm15-.75a.75.75 0 0 0-.75.75v.75c0 .414.336.75.75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75h-.75ZM9.75 15v.75a.75.75 0 0 0 .75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75h-.75a.75.75 0 0 0-.75.75Zm.002-3a2.25 2.25 0 1 0 4.5 0 2.25 2.25 0 0 0-4.5 0Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75c0-.414.336-.75.75-.75h.75Zm-6 3a.75.75 0 0 0-.75.75v.75a.75.75 0 0 0 .75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75H9.75Zm6.75-3a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75v-.75Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h18v18H3V3Z" />
  </svg>
);

export const UsersIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.75-5.25T21 9.75a9 9 0 0 0-18 0 9.094 9.094 0 0 0 3.75 5.25m10.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-10.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
  </svg>
);

export const ChatIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.455.09-.934.09-1.425v-2.134c0-2.618.92-5.04 2.5-6.818a9.023 9.023 0 0 1 6.318-3.027c5.022 0 9 3.694 9 8.25Z" />
  </svg>
);

export const MenuIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

export const TagIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6Z" />
  </svg>
);

export const ClockIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const HomeIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
    </svg>
);

export const CalendarDaysIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0h18M12 12.75h.008v.008H12v-.008Zm0 3h.008v.008H12v-.008Zm.375-6.75h.008v.008h-.008V9Zm0 3h.008v.008h-.008v-.008Zm0 3h.008v.008h-.008v-.008Zm-3-3h.008v.008H9v-.008Zm0 3h.008v.008H9v-.008Zm-3-3h.008v.008H6v-.008Zm0 3h.008v.008H6v-.008Z" />
    </svg>
);

export const SparklesIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
    </svg>
);

export const MegaphoneIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 0 1 6-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C11.176 10.658 7.69 15.08 3 17.502" />
    </svg>
);

export const InfoIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
    </svg>
);

export const LogoutIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
    </svg>
);

export const HandshakeIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path d="M14.53 9.47a.75.75 0 0 1 0 1.06l-2.5 2.5a.75.75 0 0 1-1.06 0l-2.5-2.5a.75.75 0 1 1 1.06-1.06l1.22 1.22V3.75a.75.75 0 0 1 1.5 0v7.19l1.22-1.22a.75.75 0 0 1 1.06 0ZM4.5 9.25a.75.75 0 0 0-1.5 0v3.5c0 .966.784 1.75 1.75 1.75h10.5a1.75 1.75 0 0 0 1.75-1.75v-3.5a.75.75 0 0 0-1.5 0v3.5a.25.25 0 0 1-.25.25H4.75a.25.25 0 0 1-.25-.25v-3.5Z" />
    </svg>
);
