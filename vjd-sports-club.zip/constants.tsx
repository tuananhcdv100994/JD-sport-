import React from 'react';
import { Club, Post } from './types';

export const VjdLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 400 80" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g>
      <path d="M25.79,60.5l-6.42-12.12a2.2,2.2,0,0,1,0-2.16L25.79,34.1a2.42,2.42,0,0,1,2.16,0l6.42,12.12a2.2,2.2,0,0,1,0,2.16l-6.42,12.12A2.42,2.42,0,0,1,25.79,60.5Z" fill="#1E3A8A"/>
      <path d="M47.21,60.5a2.42,2.42,0,0,1-2.16,0l-6.42-12.12a2.2,2.2,0,0,1,0-2.16L45.05,34.1a2.2,2.2,0,0,1,2.16,0l6.42,12.12a2.2,2.2,0,0,1,0,2.16Z" fill="#1E3A8A"/>
      <path d="M36.5,29.37l-12.12-6.42a2.2,2.2,0,0,1-1.08-1.08L21.14,9.75a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42a2.42,2.42,0,0,1,0,4.32l-12.12,6.42a2.2,2.2,0,0,1-1.08,1.08L21.14,53.25a2.42,2.42,0,0,1-4.32,0l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L1.46,33.69a2.42,2.42,0,0,1,0-4.32l12.12-6.42a2.2,2.2,0,0,1,1.08-1.08L26.82,9.75a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42A2.42,2.42,0,0,1,47.6,33.69l-1.08,1.08Z" fill="#1E3A8A"/>
      <path d="M36.5,47.25a2.42,2.42,0,0,1-4.32,0l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L16.82,27.63a2.42,2.42,0,0,1,0-4.32l12.12-6.42a2.2,2.2,0,0,1,1.08-1.08L42.14,3.69a2.42,2.42,0,0,1,4.32,0l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,6.42a2.42,2.42,0,0,1,0,4.32l-12.12,6.42a2.2,2.2,0,0,1-1.08,1.08L36.5,47.25Z" fill="#1E3A8A"/>
      <path d="M34.34,36.5,22.22,34.34a2.2,2.2,0,0,1-1.08-1.08L18.9,21.14a2.42,2.42,0,0,1,4.32-2.16l2.16,12.12a2.2,2.2,0,0,1,1.08,1.08l12.12,2.16a2.42,2.42,0,0,1,2.16,4.32l-12.12,2.16a2.2,2.2,0,0,1-1.08,1.08L34.34,53.25a2.42,2.42,0,0,1-4.32-2.16l-2.16-12.12a2.2,2.2,0,0,1-1.08-1.08L14.66,34.34a2.42,2.42,0,0,1-2.16-4.32l12.12-2.16a2.2,2.2,0,0,1,1.08-1.08l12.12-2.16a2.42,2.42,0,0,1,2.16,4.32L27.9,34.34a2.2,2.2,0,0,1-1.08,1.08L14.66,37.58" fill="#1E3A8A"/>
      <path d="M30,42.5a5,5,0,0,1-5-5,1.25,1.25,0,0,1,2.5,0,2.5,2.5,0,0,0,5,0,1.25,1.25,0,0,1,2.5,0,5,5,0,0,1-5,5Z" fill="#DC2626"/>
      <path d="M36.5,43.79,29.3,40.21a2.21,2.21,0,0,1-1.08-1.08l-3.58-7.21a2.42,2.42,0,0,1,4.32-2.16l3.58,7.21a2.21,2.21,0,0,1,1.08,1.08l7.21,3.58a2.42,2.42,0,0,1,2.16,4.32l-7.21,3.58a2.21,2.21,0,0,1-1.08,1.08l-3.58,7.21a2.42,2.42,0,0,1-4.32-2.16l-3.58-7.21a2.21,2.21,0,0,1-1.08-1.08l-7.21-3.58a2.42,2.42,0,0,1-2.16-4.32l7.21-3.58a2.21,2.21,0,0,1,1.08-1.08l7.21-3.58a2.42,2.42,0,0,1,2.16,4.32L36.5,34.92a2.21,2.21,0,0,1-1.08,1.08L28.21,39.58" fill="#DC2626"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(15, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(87, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(159, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(231, 36.5, 36.5)"/>
       <path d="M36.5 40.25 a1 1 0 0 1 0 -7.5 l5.2 -2.6 a1 1 0 0 1 1 1.7 l-5.2 2.6 a1 1 0 0 1 -1 0.1z" fill="white" transform="rotate(303, 36.5, 36.5)"/>
       <path d="M36.5,41.5a5,5,0,1,1,5-5,5,5,0,0,1-5,5Zm0-8.5a3.5,3.5,0,1,0,3.5,3.5A3.5,3.5,0,0,0,36.5,33Z" fill="#FBBF24"/>
    </g>
    <text x="75" y="48" fontFamily="Arial, sans-serif" fontSize="30" fontWeight="bold" fill="#1E3A8A">VJD</text>
    <text x="155" y="48" fontFamily="Arial, sans-serif" fontSize="30" fontWeight="bold" fill="#DC2626" style={{ fontStyle: 'italic' }}>sports</text>
    <text x="195" y="65" fontFamily="Arial, sans-serif" fontSize="12" fontWeight="bold" fill="#DC2626" style={{ fontStyle: 'italic' }}>GIVE IT YOUR ALL</text>
  </svg>
);


export const MOCK_CLUBS: Club[] = [
  {
    id: 'clb-quan-1',
    name: 'CLB Cầu Lông Tinh Võ',
    address: '1 Lão Tử, Phường 11, Quận 5, TP.HCM',
    activeMembers: 68,
    operatingHours: '5:00 - 23:00',
    members: Array.from({ length: 18 }, (_, i) => ({
      id: i,
      name: `VĐV ${String.fromCharCode(65 + i)}`,
      avatarUrl: `https://picsum.photos/seed/${i+1}/40/40`,
      checkedIn: i % 2 === 0,
    })),
    chat: [
      { id: 1, author: 'Anh Khoa', avatarUrl: 'https://picsum.photos/seed/a/40/40', text: 'Sân 3 tối nay trống không ad ơi?', timestamp: '10:30 AM' },
      { id: 2, author: 'Chị Lan', avatarUrl: 'https://picsum.photos/seed/b/40/40', text: 'Ad cho em thuê 1 sân từ 8-9h tối nhé!', timestamp: '10:32 AM' },
    ],
    menu: [
      { id: 1, name: 'Nước lọc Aquafina', description: 'Chai 500ml', price: '10.000đ' },
      { id: 2, name: 'Sting Dâu', description: 'Bùng nổ năng lượng', price: '15.000đ' },
      { id: 3, name: 'Cầu Hải Yến', description: 'Ống 12 quả', price: '195.000đ' },
    ],
    promotions: [
      { id: 1, title: 'Giảm 15% giờ chơi cho học sinh, sinh viên', description: 'Áp dụng các ngày trong tuần, vui lòng xuất trình thẻ.' },
    ],
  },
  {
    id: 'clb-go-vap',
    name: 'CLB Cầu Lông Gò Vấp',
    address: '12 Nguyễn Văn Lượng, Phường 6, Gò Vấp, TP.HCM',
    activeMembers: 112,
    operatingHours: '6:00 - 24:00',
     members: Array.from({ length: 35 }, (_, i) => ({
      id: i+20,
      name: `Học viên ${i + 1}`,
      avatarUrl: `https://picsum.photos/seed/${i+30}/40/40`,
      checkedIn: i % 3 === 0,
    })),
     chat: [],
     menu: [
       { id: 1, name: 'Nước Tăng Lực Monster', description: 'Thêm năng lượng cho trận đấu', price: '35.000đ' },
     ],
     promotions: [],
  },
];

export const MOCK_POSTS: Post[] = [
    {
        id: 1,
        author: { name: 'Hoàng An', avatarUrl: 'https://picsum.photos/seed/user1/40/40' },
        timestamp: '2 giờ trước',
        text: 'Cuối tuần giao lưu tại CLB Gò Vấp vui quá! Cảm ơn mọi người đã tạo ra một sân chơi bổ ích.',
        imageUrl: 'https://picsum.photos/seed/post1/600/400',
        likes: 125,
        comments: 14,
    },
    {
        id: 2,
        author: { name: 'Minh Thư', avatarUrl: 'https://picsum.photos/seed/user2/40/40' },
        timestamp: '5 giờ trước',
        text: 'Mới tậu được cây vợt mới, mai ai rảnh làm vài set giao lưu không ạ? #vjdsports #caulong',
        likes: 88,
        comments: 21,
    },
    {
        id: 3,
        author: { name: 'CLB Cầu Lông Tinh Võ', avatarUrl: 'https://picsum.photos/seed/clb1/40/40' },
        timestamp: 'Hôm qua',
        text: 'Thông báo: Giải cầu lông mở rộng VJD Sports Cup sẽ được tổ chức vào cuối tháng. Mọi người nhanh tay đăng ký nhé! Chi tiết giải đấu sẽ được cập nhật sớm.',
        likes: 210,
        comments: 45,
    }
];


export const QrCodeIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75C2.25 5.25 2.25 4.5 3 4.5h.75ZM9 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75H8.25a.75.75 0 0 1-.75-.75v-.75a.75.75 0 0 1 .75-.75h.75Zm.75 6a.75.75 0 0 0-1.5 0v.75h.75a.75.75 0 0 0 .75-.75v-.75Zm-3 2.25a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75v-.75ZM15 4.5a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75C12.75 5.25 12.75 4.5 13.5 4.5h.75Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.75v-.75a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75Zm15-.75a.75.75 0 0 0-.75.75v.75c0 .414.336.75.75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75h-.75ZM9.75 15v.75a.75.75 0 0 0 .75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75h-.75a.75.75 0 0 0-.75.75Zm.002-3a2.25 2.25 0 1 0 4.5 0 2.25 2.25 0 0 0-4.5 0Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75a.75.75 0 0 1 .75.75v.75h.75a.75.75 0 0 1 0 1.5h-.75v.75a.75.75 0 0 1-1.5 0v-.75h-.75a.75.75 0 0 1-.75-.75v-.75c0-.414.336-.75.75-.75h.75Zm-6 3a.75.75 0 0 0-.75.75v.75a.75.75 0 0 0 .75.75h.75a.75.75 0 0 0 .75-.75v-.75a.75.75 0 0 0-.75-.75H9.75Zm6.75-3a.75.75 0 0 1 .75-.75h.75a.75.75 0 0 1 .75.75v.75c0 .414-.336.75-.75.75h-.75a.75.75 0 0 1-.75-.75v-.75Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h18v18H3V3Z" />
  </svg>
);

export const UsersIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.75-5.25T21 9.75a9 9 0 0 0-18 0 9.094 9.094 0 0 0 3.75 5.25m10.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-10.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
  </svg>
);

export const ChatIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.455.09-.934.09-1.425v-2.134c0-2.618.92-5.04 2.5-6.818a9.023 9.023 0 0 1 6.318-3.027c5.022 0 9 3.694 9 8.25Z" />
  </svg>
);

export const MenuIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

export const TagIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6Z" />
  </svg>
);

export const ClockIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const InfoIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
    </svg>
);

export const LogoutIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
    </svg>
);

export const LikeIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 0 1 2.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 0 0 .322-1.672V3a.75.75 0 0 1 .75-.75A2.25 2.25 0 0 1 16.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 0 1-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 0 0-1.423-.23H5.904M6.633 10.5l-1.822 1.822a1.5 1.5 0 0 0 2.122 2.122L6.633 10.5Zm-2.121 2.122L6.633 10.5l-2.121 2.122Z" />
    </svg>
);

export const CommentIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.076-4.076a1.526 1.526 0 0 1 1.037-.443 48.282 48.282 0 0 0 5.68-.494c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z" />
    </svg>
);

export const ShareIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.186 2.25 2.25 0 0 0-3.933 2.186Z" />
    </svg>
);